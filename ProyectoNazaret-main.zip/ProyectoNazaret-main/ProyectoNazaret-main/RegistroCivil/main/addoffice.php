<form action="saveoffice.php" method="post">
Name<br>
<input type="text" name="officename" />
<br>
<input type="submit" value="Save">
</form>